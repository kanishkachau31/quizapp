# Online Quiz Application

## Overview

This is a client-side online quiz application built with vanilla HTML, CSS, and JavaScript. The application provides an interactive quiz experience with multiple-choice questions, customizable timer settings, real-time scoring, and a responsive user interface. Users can take timed quizzes, receive instant feedback on their answers, and view their final results upon completion.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Single-Page Application (SPA)**: Built entirely with vanilla web technologies without frameworks
- **Class-Based JavaScript**: Uses ES6+ class structure (`QuizApp`) for organizing application logic
- **Screen-Based UI**: Implements multiple screens (start, quiz, results) with show/hide functionality
- **Progressive Enhancement**: Core functionality works without JavaScript, enhanced with interactive features

### UI/UX Design Patterns
- **Card-Based Layout**: Question content displayed in clean, card-style containers
- **Responsive Design**: Mobile-first approach with flexible layouts and media queries
- **Visual Feedback**: Progress bars, color-coded answer feedback, and smooth transitions
- **Timer Integration**: Real-time countdown with visual indicators

### Data Management
- **Static Question Pool**: Questions stored as JavaScript objects within the application code
- **Client-Side State**: All quiz state (current question, score, timer) managed in browser memory
- **Session-Based**: No persistent storage - quiz data resets on page refresh

### Component Structure
- **Question Management**: Centralized question rendering and validation logic
- **Timer System**: Countdown functionality with automatic quiz submission on timeout
- **Score Tracking**: Real-time score calculation and display
- **Navigation Control**: Screen transitions and user flow management

## External Dependencies

### Core Technologies
- **HTML5**: Semantic markup and form elements
- **CSS3**: Styling with flexbox, grid, gradients, and animations
- **Vanilla JavaScript**: ES6+ features including classes, arrow functions, and modern DOM APIs

### Browser APIs
- **DOM Manipulation**: Direct DOM element selection and modification
- **Event Handling**: Click, input, and timer events
- **Local Storage**: Potential for score persistence (architecture supports future implementation)

### Assets and Resources
- **Custom CSS**: Self-contained styling without external CSS frameworks
- **Font Stack**: System fonts (Segoe UI, Tahoma, Geneva, Verdana)
- **No External Libraries**: Completely self-contained application

### Future Integration Points
- **Database Integration**: Architecture supports adding persistent question storage
- **Authentication System**: User management can be added without major refactoring
- **API Integration**: Question fetching from external sources easily implementable
- **Analytics Tracking**: Event-based architecture supports adding usage analytics